localizedTextByLang = {
    "en": {
        "start-button": "Get Started",
        "slideText1": "See your jobs on a map.",
        "slideText2": "Get quick access to service history.",
        "slideText3": "Seamlessly track progress.",
        "slideText4": "Easily scan barcodes.",
        "slideText5": "Capture signatures digitally.",
        "endframe-button": "Log In",
        "skip-button": "Skip"

    },
    "cs": { 
        "start-button": "Začněte",
        "slideText1": "Zobrazte své úkoly na mapě.",
        "slideText2": "Získejte rychlý přístup k historii služeb.",
        "slideText3": "Jednoduše sledujte postup práce.",
        "slideText4": "Snadno skenujte čárové kódy.",
        "slideText5": "Snímejte podpisy digitálně.",
        "endframe-button": "Přihlášení",
        "skip-button": "Přeskočit"
    },
    "da": { 
        "start-button": "Kom i gang",
        "slideText1": "Se dine job på et kort.",
        "slideText2": "Få hurtig adgang til servicehistorik.",
        "slideText3": "Spor status uden problemer.",
        "slideText4": "Scan stregkoder uden problemer.",
        "slideText5": "Registrer signaturer digitalt.",
        "endframe-button": "Log ind",
        "skip-button": "Ignorer"
    },
    "de": { 
        "start-button": "Erste Schritte",
        "slideText1": "Anzeigen Ihrer Aufträge auf einer Karte.",
        "slideText2": "Schneller Zugriff auf den Serviceverlauf.",
        "slideText3": "Problemlose Fortschrittsverfolgung.",
        "slideText4": "Leichtes Scannen von Barcodes.",
        "slideText5": "Digitale Aufzeichnung von Unterschriften.",
        "endframe-button": "Anmelden",
        "skip-button": "Überspringen"
    },
    "el": { 
        "start-button": "Πρώτα βήματα",
        "slideText1": "Δείτε θέσεις εργασίας στο χάρτη.",
        "slideText2": "Αποκτήστε γρήγορη πρόσβαση στο ιστορικό υπηρεσίας.",
        "slideText3": "Παρακολουθήστε απρόσκοπτα την εξέλιξη.",
        "slideText4": "Σαρώστε εύκολα γραμμωτούς κωδικούς.",
        "slideText5": "Αποτυπώστε ψηφιακά τις υπογραφές.",
        "endframe-button": "Σύνδεση",
        "skip-button": "Παράλειψη"
    },
    "es": { 
        "start-button": "Comenzar",
        "slideText1": "Vea sus trabajos en un mapa.",
        "slideText2": "Obtenga un acceso rápido al historial de servicio.",
        "slideText3": "Realice un seguimiento del progreso de forma sencilla.",
        "slideText4": "Escanee fácilmente códigos de barras.",
        "slideText5": "Capturar firmas digitalmente.",
        "endframe-button": "Iniciar sesión",
        "skip-button": "Omitir"
    },
    "fi": { 
        "start-button": "Aluksi",
        "slideText1": "Näe työsi kartalla.",
        "slideText2": "Nopea pääsy palveluhistoriaan.",
        "slideText3": "Seuraa saumattomasti edistymistä.",
        "slideText4": "Lue viivakoodit helposti.",
        "slideText5": "Tallenna allekirjoitukset digitaalisesti.",
        "endframe-button": "Sisäänkirjautuminen",
        "skip-button": "Ohita"
    },
    "fr": { 
        "start-button": "Commencer",
        "slideText1": "Affichez vos tâches sur une carte.",
        "slideText2": "Accédez rapidement à l'historique des services.",
        "slideText3": "Suivez de façon transparente la progression.",
        "slideText4": "Scannez aisément des codes à barres.",
        "slideText5": "Capturez les signatures numériquement.",
        "endframe-button": "Se connecter",
        "skip-button": "Ignorer"
    },
    "hu": { 
        "start-button": "Kezdő lépések",
        "slideText1": "Tekintse meg az állásokat egy térképen.",
        "slideText2": "Gyorsan elérheti a szolgáltatási előzményeket.",
        "slideText3": "Zökkenőmentesen nyomon követheti az előrehaladást.",
        "slideText4": "Egyszerűen beolvashatja a vonalkódokat.",
        "slideText5": "Digitálisan rögzíthet aláírásokat.",
        "endframe-button": "Bejelentkezés",
        "skip-button": "Kihagyás"
    },
    "id": { 
        "start-button": "Memulai",
        "slideText1": "Lihat pekerjaan Anda di peta.",
        "slideText2": "Dapatkan akses cepat ke riwayat layanan.",
        "slideText3": "Melacak kemajuan dengan mulus.",
        "slideText4": "Memindai barcode dengan mudah.",
        "slideText5": "Membuat gambar tanda tangan secara digital.",
        "endframe-button": "Masuk",
        "skip-button": "Lewati"
    },
    "it": { 
        "start-button": "Per iniziare",
        "slideText1": "Guarda i tuoi lavori su una mappa.",
        "slideText2": "Accedi rapidamente alla cronologia di servizi.",
        "slideText3": "Tieni traccia dell'avanzamento in modo fluido.",
        "slideText4": "Leggi facilmente i codici a barre.",
        "slideText5": "Acquisisci le firme in digitale.",
        "endframe-button": "Accedi",
        "skip-button": "Salta"
    },
    "ja": { 
        "start-button": "使用を開始する。",
        "slideText1": "マップにジョブを表示する。",
        "slideText2": "サービス履歴にすばやくアクセスする。",
        "slideText3": "進行状況をシームレスに追跡する。",
        "slideText4": "バーコードを簡単にスキャンする。",
        "slideText5": "署名をデジタルでキャプチャする。",
        "endframe-button": "ログイン",
        "skip-button": "スキップ"
    },
    "ko": { 
        "start-button": "시작하기",
        "slideText1": "지도에서 작업을 확인합니다.",
        "slideText2": "서비스 기록에 빠르게 액세스합니다.",
        "slideText3": "진행률을 매끄럽게 추적합니다.",
        "slideText4": "바코드를 간편하게 스캔합니다.",
        "slideText5": "서명을 디지털로 수집합니다.",
        "endframe-button": "로그인",
        "skip-button": "건너뛰기"
    },
    "nl": { 
        "start-button": "Aan de slag",
        "slideText1": "Uw taken op een kaart.",
        "slideText2": "Snelle toegang tot de servicehistorie.",
        "slideText3": "Naadloos de voortgang volgen",
        "slideText4": "Gemakkelijk streepjescodes scannen.",
        "slideText5": "Digitale handtekeningen registreren.",
        "endframe-button": "Inloggen",
        "skip-button": "Overslaan"
    },
    "no": { 
        "start-button": "Kom i gang",
        "slideText1": "Se jobbene dine på et kart.",
        "slideText2": "Få rask tilgang til tjenestehistorikk.",
        "slideText3": "Spor fremdriften sømløst.",
        "slideText4": "Skann strekkoder enkelt.",
        "slideText5": "Registrer signaturer digitalt.",
        "endframe-button": "Logg på",
        "skip-button": "Hopp over"
    },
    "pl": { 
        "start-button": "Rozpocznij",
        "slideText1": "Zobacz swoje zadania na mapie.",
        "slideText2": "Przeglądaj szybko historię serwisową.",
        "slideText3": "Bezbłędnie obserwuj postęp.",
        "slideText4": "W łatwy sposób skanuj kody kreskowe.",
        "slideText5": "Pobieraj cyfrowo podpisy.",
        "endframe-button": "Zaloguj",
        "skip-button": "Pomiń"
    },
    "pt-br": {
        "start-button": "Introdução",
        "slideText1": "Veja seus trabalhos em um mapa.",
        "slideText2": "Obtenha acesso rápido ao histórico de serviços.",
        "slideText3": "Rastreie o progresso sem interrupção.",
        "slideText4": "Leia códigos de barras com facilidade.",
        "slideText5": "Capture assinaturas digitalmente.",
        "endframe-button": "Login",
        "skip-button": "Ignorar"
    },
    "ro": { 
        "start-button": "Început",
        "slideText1": "Vizualizați lucrările pe o hartă.",
        "slideText2": "Beneficiați de acces rapid la istoricul serviciului.",
        "slideText3": "Urmăriți progresul fără probleme.",
        "slideText4": "Scanați cu ușurință coduri de bare.",
        "slideText5": "Capturați semnături digitale.",
        "endframe-button": "Conectare",
        "skip-button": "Ignorare"
    },
    "ru": { 
        "start-button": "Начало работы",
        "slideText1": "Отображение заданий на карте.",
        "slideText2": "Получение быстрого доступа к журналу обслуживания.",
        "slideText3": "Беспрепятственное отслеживание хода выполнения.",
        "slideText4": "Удобное сканирование штрих-кодов.",
        "slideText5": "Получение цифровых подписей.",
        "endframe-button": "Вход",
        "skip-button": "Пропустить"
    },
    "sv": { 
        "start-button": "Kom igång",
        "slideText1": "Se dina jobb på en karta.",
        "slideText2": "Få snabb åtkomst till servicehistorik.",
        "slideText3": "Sömlös spårning pågår.",
        "slideText4": "Skanna barkoder enkelt.",
        "slideText5": "Ta bild av signaturer digitalt.",
        "endframe-button": "Logga in",
        "skip-button": "Hoppa över"
    },
    "th": { 
        "start-button": "เริ่มต้น",
        "slideText1": "ดูงานของคุณบนแผนที่",
        "slideText2": "เข้าถึงประวัติการให้บริการได้อย่างรวดเร็ว",
        "slideText3": "ติดตามความคืบหน้าได้อย่างต่อเนื่อง",
        "slideText4": "สแกนบาร์โค้ดได้ง่าย",
        "slideText5": "จับภาพลายเซ็นในรูปแบบดิจิตัล",
        "endframe-button": "เข้าสู่ระบบ",
        "skip-button": "ข้าม"
    },
    "tr": { 
        "start-button": "Başla",
        "slideText1": "İşlerinizi haritada görün.",
        "slideText2": "Hizmet geçmişine hızlı erişim.",
        "slideText3": "İlerlemeyi sorunsuzca takip edin.",
        "slideText4": "Barkodları kolayca tarayın.",
        "slideText5": "İmzaları dijital olarak yakalayın.",
        "endframe-button": "Oturum Aç",
        "skip-button": "Atla"
    },
    "uk": { 
        "start-button": "Розпочніть роботу",
        "slideText1": "Побачити завдання на карті.",
        "slideText2": "Отримати швидкий доступ до журналу обслуговування.",
        "slideText3": "Без проблем відслідковувати хід виконання.",
        "slideText4": "Легко сканувати штрихкоди.",
        "slideText5": "Знімати підписи у цифровій формі.",
        "endframe-button": "Вхід",
        "skip-button": "Пропустити"
    },
    "vi": { 
        "start-button": "Bắt Đầu",
        "slideText1": "Xem công việc của bạn trên bản đồ.",
        "slideText2": "Truy cập nhanh vào lịch sử dịch vụ.",
        "slideText3": "Theo dõi tiến độ liền mạch.",
        "slideText4": "Quét mã vạch thật dễ dàng.",
        "slideText5": "Ký bằng phương tiện điện tử.",
        "endframe-button": "Đăng Nhập",
        "skip-button": "Bỏ Qua"
    },
    "zh": {
        "start-button": "开始使用",
        "slideText1": "在地图上查看您的任务。",
        "slideText2": "快速访问服务历史。",
        "slideText3": "无缝跟踪进度。",
        "slideText4": "轻松扫描条形码。",
        "slideText5": "以数字化方式捕获签名。",
        "endframe-button": "登录",
        "skip-button": "跳过"
    },
    "zh-tw": {
        "start-button": "開始",
        "slideText1": "在地圖上查看您的工作。",
        "slideText2": "快速存取服務歷程記錄。",
        "slideText3": "順暢地追蹤進度。",
        "slideText4": "輕鬆掃描條碼。",
        "slideText5": "數位擷取簽名。",
        "endframe-button": "登入",
        "skip-button": "略過"
    }
};
