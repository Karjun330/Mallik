var initCarousel = function initCarousel(elementId) {
	//determine width of each slide-track
	//give slide track inline width
	//hook-up hammer
	var NEXT = "next";
	var PREV = "prev";
	var START_BUTTON_ID = "start-button";
	var wrapper = document.getElementById(elementId);
	var track = wrapper.querySelector(".slide-track");
	var slides = Array.from(wrapper.querySelectorAll(".slide-item"));
	var currentClass = "slide-item--current";
	var hammerTime = new Hammer(track);
	var currentSlide = 0;

	var applyWidth = function applyWidth(element, widthVal) {
		console.log("Applying width of", widthVal, "to", element);
		element.style.width = widthVal + 'px';
	}; // import $ from 'jquery'; Before using jQuery, install it with `npm install --save jquery`


	var isEndframe = function isEndframe(element, slides, idx) {
		element.classList.toggle("is-endframe", idx === 0 || idx === slides.length - 1);
		element.classList.toggle("is-demo", idx > 0 && idx < slides.length - 1);
	};

	var updateProcess = function updateProcess(currentIdx) {
		var dots = Array.from(document.querySelectorAll(".process-dot"));
		dots.map(function (dot, i) {
			return dot.classList.toggle("is-current", i === currentIdx);
		});
	};

	var getTrackTransformStyle = function getTrackTransformStyle(curIdx) {
		return 'translate3d(-' + parseInt(track.style.width) / slides.length * curIdx + 'px, 0, 0)';
	};

	var moveCarousel = function moveCarousel(nextSlide) {
		slides.map(function (slide) {
			slide.classList.remove(currentClass);
			hideAccesible(slide);
			return slide;
		});
		currentSlide = nextSlide;
		slides[currentSlide].classList.add(currentClass);
		showAccesible(slides[currentSlide]);

		isEndframe(wrapper, slides, currentSlide);
		track.style.transform = getTrackTransformStyle(currentSlide);
		updateProcess(currentSlide);
		manageButtonA11y(currentSlide + 1, slides.length);
		updateA11yStatus(currentSlide + 1, slides.length);
	};

	var handleSlideClick = function handleSlideClick(e) {
		if (e.target.id === START_BUTTON_ID) return false;
		var direction = ["swipeleft", "tap", "press"].includes(e.type) ? NEXT : e.type === "swiperight" ? PREV : false;
		if (!direction) return false;
		advanceSlide(direction, e);
	};

	var advanceSlide = function advanceSlide(direction, e) {
		if (currentSlide >= slides.length - 1 && direction === NEXT) return false;
		if (currentSlide <= 0 && direction === PREV) return false;
		moveCarousel(direction === NEXT ? currentSlide + 1 : currentSlide - 1);
		return false;
	};

	var handleSkipClick = function handleSkipClick(e) {
		moveCarousel(slides.length - 1);
		return false;
	};

	var slideWidths = slides.map(function (slide) {
		var rect = slide.getBoundingClientRect();
		applyWidth(slide, rect.width);
		return rect.width;
	});

	var updateA11yStatus = function updateA11yStatus(curSlide, length) {
		document.querySelector("#carousel-0-status span").innerText = 'Showing slide ' + curSlide + ' of ' + length;
	};

	var showAccesible = function showAccesible(el) {
		el.removeAttribute("aria-hidden");
		el.removeAttribute("tabindex");
		el.setAttribute("aria-disabled", "false");
	};

	var hideAccesible = function hideAccesible(el) {
		el.setAttribute("aria-hidden", "true");
		el.setAttribute("tabindex", -1);
		el.setAttribute("aria-disabled", "true");
	};

	var manageButtonA11y = function manageButtonA11y(curSlide, length) {
		var prevBtn = document.querySelector("#slide-advance-a11y__prev");
		var nextBtn = document.querySelector("#slide-advance-a11y__next");
		var skipBtn = document.querySelector(".button--skip");
		[prevBtn, nextBtn, skipBtn].forEach(function (el) {
			return showAccesible(el);
		});
		if (curSlide === 1) hideAccesible(prevBtn);
		if (curSlide === length) {
			hideAccesible(nextBtn);
			hideAccesible(skipBtn);
		}
	};

	applyWidth(track, slideWidths.reduce(function (accumulator, currentValue) {
		return accumulator + currentValue;
	}, 0));

	moveCarousel(0);
	hammerTime.on("swipeleft swiperight tap press", handleSlideClick);
	document.querySelector(".button--skip").addEventListener("click", handleSkipClick);
	document.getElementById(START_BUTTON_ID).addEventListener("click", advanceSlide.bind(undefined, NEXT));
	document.querySelector("#slide-advance-a11y__prev").addEventListener("click", advanceSlide.bind(undefined, PREV));
	document.querySelector("#slide-advance-a11y__next").addEventListener("click", advanceSlide.bind(undefined, NEXT));

	setTimeout(function () {
		wrapper.classList.add("is-viz");
	}, 100);
};

initCarousel("carousel-onboarding");
