var applyWidth = function applyWidth(element, widthVal) {
	console.log("Applying width of", widthVal, "to", element);
	element.style.width = widthVal + 'px';
};

var isEndframe = function isEndframe(element, slides, idx) {
	element.classList.toggle("is-endframe", idx === 0 || idx === slides.length - 1);
	element.classList.toggle("is-demo", idx > 0 && idx < slides.length - 1);
};

var updateProcess = function updateProcess(currentIdx) {
	var dots = Array.from(document.querySelectorAll(".process-dot"));
	dots.map(function (dot, i) {
		return dot.classList.toggle("is-current", i === currentIdx);
	});
};

var initCarousel = function initCarousel(elementId) {
	var NEXT = "next";
	var PREV = "prev";
	var wrapper = document.getElementById(elementId);
	var track = wrapper.querySelector(".slide-track");
	var slides = Array.from(wrapper.querySelectorAll(".slide-item"));
	var currentClass = "slide-item--current";
	var currentSlide = 0;

	var getTrackTransformStyle = function (curIdx) {
		return 'translate3d(-' + parseInt(track.style.width) / slides.length * curIdx + 'px, 0, 0)';
	};

	var moveCarousel = function (nextSlide) {
		slides.map(function (slide) {
			slide.classList.remove(currentClass);
			hideAccessible(slide);
			return slide;
		});
		currentSlide = nextSlide;
		slides[currentSlide].classList.add(currentClass);
		showAccessible(slides[currentSlide]);

		isEndframe(wrapper, slides, currentSlide);
		track.style.transform = getTrackTransformStyle(currentSlide);
		updateProcess(currentSlide);
		manageButtonA11y(currentSlide + 1, slides.length);
		updateA11yStatus(currentSlide + 1, slides.length);
	};

	var advanceSlide = function (direction, e) {
		if (currentSlide >= slides.length - 1 && direction === NEXT) return false;
		if (currentSlide <= 0 && direction === PREV) return false;
		moveCarousel(direction === NEXT ? currentSlide + 1 : currentSlide - 1);
		return false;
	};

	var slideWidths = slides.map(function (slide) {
		var rect = slide.getBoundingClientRect();
		applyWidth(slide, rect.width);
		return rect.width;
	});

	var updateA11yStatus = function (curSlide, length) {
		document.querySelector("#carousel-0-status span").innerText = 'Showing slide ' + curSlide + ' of ' + length;
	};

	var showAccessible = function (el) {
		el.removeAttribute("aria-hidden");
		el.removeAttribute("tabindex");
		el.setAttribute("aria-disabled", "false");
	};

	var hideAccessible = function (el) {
		el.setAttribute("aria-hidden", "true");
		el.setAttribute("tabindex", -1);
		el.setAttribute("aria-disabled", "true");
	};

	var manageButtonA11y = function (curSlide, length) {
		var prevBtn = document.querySelector("#slide-advance-a11y__prev");
		var nextBtn = document.querySelector("#slide-advance-a11y__next");
		[prevBtn, nextBtn].forEach(showAccessible);

		if (curSlide === 1) hideAccessible(prevBtn);
		if (curSlide === length) hideAccessible(nextBtn);
	};

	applyWidth(track, slideWidths.reduce(function (accumulator, currentValue) {
		return accumulator + currentValue;
	}, 0));

	moveCarousel(0);
	document.querySelectorAll(".button--reset").forEach(function (el) {
		el.addEventListener("click", advanceSlide.bind(undefined, NEXT));
	});
	document.querySelector("#slide-advance-a11y__prev").addEventListener("click", advanceSlide.bind(undefined, PREV));
	document.querySelector("#slide-advance-a11y__next").addEventListener("click", advanceSlide.bind(undefined, NEXT));
};

setTimeout(function () {
	initCarousel("carousel-onboarding");
}, 350);
